package program2;
/*
 * Programmer .: Isaac Oxendale & Joe Ermatinger
 * Date . . . .: 2019-04-02
 * Program Name: Person.java
 */

class Person 
{
	//variable declarations
	private String name;
	private String address;
	private String phone;

	//no-arg constructor for Person
	public Person() 
	{
		name = "";
		phone = "";
		address = "";
	}
	
	//full-arg constructor for Person
	public Person(String name, String address, String phone) {

		this.name = name;
		this.address = address;
		this.phone = phone;
	}

	// field getters
	public String getName() {
		return name;
	}

	public String getAddress() {
		return address;
	}

	public String getPhone() {
		return phone;
	}

	// field setters
	public void setName(String name) {
		this.name = name;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

}