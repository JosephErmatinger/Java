// Personal.java Created by: Joe Ermatinger 2/05/2018   

public class Personal
{
	public static void main(String[] args)
	{
		//display heading
		System.out.println("Personal.java Created by: Joe Ermatinger");
		
		//initialize variables
		String name = "Joe Ermatinger";
		String street = "123 Street";
		String city = "Grand Rapids";
		String state = "MI";
		String zip = "49501";
		String telephoneNumber = "555 321 1234";
		String collegeMajor = "Computer Information Systems: Software Engineer";
		
		//display output
		System.out.println( name + "\n" + street + "\n" + city + "\n" + state + "\n" + zip + "\n" + telephoneNumber + "\n" + collegeMajor );
	}
}
		