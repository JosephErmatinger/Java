// MyName.java Created by: Joe Ermatinger 2/05/2018   

public class MyName 
{
	public static void main(String[] args) 
	{
		//display heading
		System.out.println("MyName.java Created by: Joe Ermatinger");
		
		//initialize variables
		String name = "Joe Mahoney";
		int age = 26;
		double annualPay = 100000.0;
		
		//display output
		System.out.print("My name is " + name + ", my age is " + age + ", and \nI hope to earn $" + annualPay + " per year.");
	}
}
